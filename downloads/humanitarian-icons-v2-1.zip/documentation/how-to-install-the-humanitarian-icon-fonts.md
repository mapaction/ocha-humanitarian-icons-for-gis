# How to install the humanitrian icon font
These fonts were created by OCHA as SVG files which were there converted into the font formats using [IcoMoon](https://icomoon.io/app/#/select).

## How to use
* Download the font - [Humanitarian-Icons.ttf](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/raw/humanitarian-icons-v2/humanitarian-icons-v2-1-font/Humanitarian-Icons.ttf)
* Double click to install.
<img src="https://github.com/mapaction/ocha-humanitarian-icons-for-gis/blob/humanitarian-icons-v2/documentation/images/fonts-view.jpg" alt="Fonts" width="95%" align="centre" >

## Other font file types

* .eot - [Humanitarian-Icons.eot](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/raw/humanitarian-icons-v2/humanitarian-icons-v2-1-font/Humanitarian-Icons.eot)
* .woff - [Humanitarian-Icons.woff](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/raw/humanitarian-icons-v2/humanitarian-icons-v2-1-font/Humanitarian-Icons.woff)
