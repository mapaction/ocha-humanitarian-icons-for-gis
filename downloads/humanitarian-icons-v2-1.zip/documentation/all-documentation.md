# All documentation

Below are the links to all the documents:

* [Icon lookup table](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/blob/humanitarian-icons-v2/documentation/icon-lookup-table.md)
* [Fonts](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/blob/humanitarian-icons-v2/documentation/fonts-readme.md)
* [How to install the humanitarian icons in ArcMap 10.6](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/blob/humanitarian-icons-v2/documentation/how-to-install-the-humanitarian-icons-in-arcmap-10-6.md)
* [How to install the humanitarian icons in ArcGIS Pro 2.5](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/blob/humanitarian-icons-v2/documentation/how-to-install-the-humanitarian-icons-in-arcgis-pro-2-5.md)
* [How to install the humanitarian icons in QGIS](https://github.com/mapaction/ocha-humanitarian-icons-for-gis/blob/humanitarian-icons-v2/documentation/how-to-install-the-humanitarian-icons-in-qgis.md)