# Humanitrian Icon Font
These fonts were created by OCHA as SVG files which were there converted into the font formats using [IcoMoon](https://icomoon.io/app/#/select).

## How to use
* Download the font
* Double click to install